# PRD — Platform Sekolah Sehat Sumbar (Stratifikasi UKS/M)

> Versi 0.5 · Stack: **Laravel 12** + **MySQL/phpMyAdmin** · 24 Juni 2026
> Sumber kebenaran tunggal (single source of truth) konteks proyek.
> **Jika dipakai dengan Claude Code: salin §0, §6, §7, §8, §11 ke `CLAUDE.md`.**
> Pendamping belajar: lihat **`PANDUAN_BELAJAR_LARAVEL12.md`** (langkah-demi-langkah untuk developer junior).

---

## 0. Untuk Claude Code — BACA INI DULU

### 0.1 Kebutuhan sistem & stack (final)
- **Framework**: **Laravel 12** (rilis Feb 2025; minimum **PHP 8.2**, disarankan **PHP 8.3/8.4**).
- **Database**: **MySQL 8** / MariaDB 10.6+ (charset `utf8mb4`, engine InnoDB). Administrasi DB pakai **phpMyAdmin** (lokal lewat XAMPP/Laragon). Skema lengkap di **§7A**. Produksi: MySQL/MariaDB.
- **Frontend**: Blade + Tailwind CSS, interaksi ringan dengan Alpine.js. Auth pakai **Laravel Breeze (stack Blade)**. (Alternatif: starter kit Livewire bila ingin komponen reaktif.)
- **Penyimpanan berkas bukti**: `Storage` disk **private** (`storage/app/private` — default disk lokal Laravel 12). Bukti TIDAK boleh dapat diakses publik tanpa otorisasi.
- **Impor Excel instrumen**: paket `maatwebsite/excel`.
- **Tooling**: Composer, Node.js + npm (Vite), Git. Format kode: **Laravel Pint**. Test: **Pest** (atau PHPUnit).
- **Catatan versi Laravel 12**: aturan validasi `image` tidak lagi mengizinkan SVG secara default; disk lokal default ke `storage/app/private`. Perhatikan saat menulis validasi upload & path bukti.

### 0.2 Prinsip rancang
- Antarmuka **ringan** (operator sering pakai HP & jaringan terbatas) → utamakan Blade server-rendered.
- **Bahasa domain Indonesia** untuk nama model/field/fungsi (`Pengajuan`, `JawabanIndikator`, `verifikasi()`).
- **Lapisan logika terpusat**: SEMUA alur status, validasi bisnis, dan penegakan wilayah ada di **kelas Service** (`app/Services/`). **Controller tipis** (hanya validasi input via Form Request → panggil Service → return view/redirect). **Model = Eloquent**, tanpa logika lintas-entitas. **Otorisasi via Policy/Gate**.
- **Skor & kelayakan dihitung di server**, tidak percaya angka dari klien.

### 0.3 Larangan
- Jangan menaruh kredensial/secret/data nyata peserta didik di repo (pakai `.env`, jangan commit `.env`).
- Jangan menonaktifkan gerbang validasi submit (§8.3).
- Jangan menurunkan strata sekolah otomatis.
- Jangan biarkan verifikator memproses sekolah di luar wilayahnya (penegakan di Service + Policy, §4 & §5A).
- Jangan simpan bukti di disk `public`.

### 0.4 Urutan pengerjaan
Kerjakan **M0 → M7 berurutan** (§12). Tiap milestone punya *Definition of Done*. Tulis test Service lebih dulu, baru controller/view.

---

## 1. Ringkasan

Aplikasi web **pemetaan, self-assessment, dan verifikasi berjenjang** stratifikasi UKS/M seluruh sekolah di Provinsi Sumatera Barat. Operator sekolah menilai diri terhadap instrumen resmi & mengunggah bukti → pengajuan diverifikasi bertingkat **kecamatan → kab/kota → provinsi** sesuai wilayah → strata ditetapkan & terpetakan.

## 2. Masalah & tujuan
Penilaian stratifikasi UKS selama ini manual (kertas/Excel): sulit direkap, lambat diverifikasi lintas wilayah, tanpa jejak audit. Tujuan:
- Operator: self-assessment terstruktur + upload bukti per indikator.
- Tim verifikasi: alur kerja jelas, **terbagi otomatis per wilayah**, dengan jejak audit.
- Dinas: rekap & peta sebaran strata untuk pengambilan keputusan.

## 3. Lingkup
**Tahap ini (M0–M6)**: model data, manajemen user & wilayah, **verifikasi berbasis wilayah**, self-assessment operator + upload bukti per strata, verifikasi berjenjang, dashboard rekap dasar, RBAC penuh.
**Belum (M7+)**: ekspor PDF/Excel matang, sertifikat strata, peta interaktif, notifikasi, kesiapan skala/produksi.

---

## 4. Peran, hierarki, & RBAC

Lima peran. Cakupan wilayah **ditegakkan di Service + Policy** — bukan sekadar disembunyikan di UI.

| Peran | Kode | Cakupan data | Wewenang utama |
|---|---|---|---|
| Operator Sekolah | `OPERATOR` | 1 sekolah | Kelola data sekolahnya, isi & ajukan self-assessment, unggah bukti, lihat status |
| Verifikator Kecamatan | `VERIF_KEC` | 1 kecamatan | Verifikasi tahap 1 |
| Verifikator Kab/Kota | `VERIF_KAB` | 1 kab/kota | Verifikasi tahap 2 |
| Verifikator Provinsi | `VERIF_PROV` | se-Sumbar | Verifikasi tahap 3 (final) |
| Administrator | `ADMIN` | semua | Kelola master data, user & wilayah; lihat semua; bypass cakupan |

**Matriks akses (ringkas):**

| Aksi | OPERATOR | VERIF_KEC | VERIF_KAB | VERIF_PROV | ADMIN |
|---|---|---|---|---|---|
| Lihat/edit data sekolah sendiri | ✓ | – | – | – | ✓ (semua) |
| Buat & isi pengajuan | ✓ | – | – | – | ✓ |
| Upload bukti | ✓ | – | – | – | ✓ |
| Lihat antrian verifikasi | – | ✓ (kec.) | ✓ (kab.) | ✓ (prov.) | ✓ (semua) |
| Setujui / kembalikan / tolak | – | ✓ tahap 1 | ✓ tahap 2 | ✓ tahap 3 | ✓ semua tahap |
| Kelola user & wilayah | – | – | – | – | ✓ |
| Lihat dashboard & rekap | hanya sekolahnya | wilayahnya | wilayahnya | semua | semua |

---

## 5. Manajemen User & Wilayah

Dikelola **Administrator** (sebagian self-service operator). Setiap user terikat peran + wilayah/sekolah agar RBAC §4 & verifikasi berbasis wilayah §5A bisa ditegakkan.

### 5.1 Entitas `Profil` (1–1 dengan `User`)
- `user_id` → relasi 1-1 ke `users` (auth bawaan Laravel)
- `peran` → enum kode peran (§4)
- `sekolah_id` → **wajib bila** `OPERATOR`
- `kecamatan_id` → **wajib bila** `VERIF_KEC`
- `kabupaten_kota_id` → **wajib bila** `VERIF_KAB`
- `no_hp`, `nip` (opsional), `aktif` (bool), `harus_ganti_password` (bool), `terakhir_login`

**Validasi konsistensi peran↔cakupan** (di Service + `Form Request`): tolak (`ValidasiGagal`) bila peran & cakupan tak cocok (mis. `VERIF_KEC` tanpa `kecamatan_id`).

### 5.2 CRUD User (Admin)
Daftar (filter peran & kab/kota, cari nama/email) · Tambah (field cakupan **muncul kondisional** sesuai peran; password sementara + paksa ganti saat login pertama) · Edit (revalidasi, reset password, aktif/nonaktif — **bukan hapus**, demi audit) · Impor massal (opsional M7).

### 5.3 Self-service Operator
Operator boleh memperbarui profil sekolahnya + kontak pribadi; **tidak** boleh ubah peran/cakupan sendiri. Sekolah baru diajukan → disetujui Admin/verifikator wilayah (`Sekolah.terverifikasi`).

---

## 5A. Verifikasi berbasis wilayah Sumatera Barat (FOKUS BARU)

Tujuan: tim penilai hanya melihat & memverifikasi sekolah **di wilayahnya sendiri**, mengikuti struktur administratif Sumbar.

### 5A.1 Hierarki wilayah
```
Provinsi Sumatera Barat
 └── KabupatenKota (19)
      └── Kecamatan (banyak)
           └── Sekolah (banyak)
                └── Pengajuan → diverifikasi: KEC → KAB → PROV
```
Setiap `Sekolah` wajib punya `kecamatan_id` (dan otomatis tahu `kabupaten_kota_id` lewat relasi `Kecamatan→KabupatenKota`).

### 5A.2 Master 19 Kabupaten/Kota Sumbar (seed wajib)
**Kabupaten (12)**: Agam, Dharmasraya, Kepulauan Mentawai, Lima Puluh Kota, Padang Pariaman, Pasaman, Pasaman Barat, Pesisir Selatan, Sijunjung, Solok, Solok Selatan, Tanah Datar.
**Kota (7)**: Bukittinggi, Padang, Padang Panjang, Pariaman, Payakumbuh, Sawahlunto, Solok.
> Total 19. Kecamatan diisi per kab/kota (boleh bertahap; minimal lengkap untuk wilayah ujicoba).

### 5A.3 Aturan penyaringan antrian (logika Service)
Saat verifikator membuka `/verifikasi`, antrian dibangun dari `Pengajuan` yang **status-nya cocok dengan level peran** DAN **wilayahnya cocok dengan cakupan profil**:

| Peran | Filter status | Filter wilayah |
|---|---|---|
| `VERIF_KEC` | `status = VERIF_KEC` | `sekolah.kecamatan_id = profil.kecamatan_id` |
| `VERIF_KAB` | `status = VERIF_KAB` | `sekolah.kecamatan.kabupaten_kota_id = profil.kabupaten_kota_id` |
| `VERIF_PROV` | `status = VERIF_PROV` | (tanpa filter — se-Sumbar) |
| `ADMIN` | semua status verif | (tanpa filter) |

Implementasi Laravel: query terfilter di Service (mis. `VerifikasiService::antrian(Profil $aktor)`), diperkuat **Policy** `VerifikasiPolicy::proses()` yang mengecek kecocokan wilayah sebelum aksi apa pun. Akses ke luar wilayah → `AksesDitolak` (HTTP 403), bukan diam-diam mengosongkan data.

### 5A.4 Acceptance criteria §5A
- [ ] Seeder mengisi tepat 19 kab/kota.
- [ ] `VERIF_KEC` Kec. Padang Timur hanya melihat pengajuan sekolah Kec. Padang Timur berstatus `VERIF_KEC`.
- [ ] `VERIF_KAB` Kota Padang melihat semua kecamatan di Kota Padang (status `VERIF_KAB`), tidak melihat Bukittinggi.
- [ ] `VERIF_PROV` melihat seluruh Sumbar (status `VERIF_PROV`).
- [ ] Verifikator luar wilayah membuka URL pengajuan langsung → 403.

---

## 6. Domain: Stratifikasi UKS/M
- **Jenjang** (3 sheet Excel): `SDMI` (SD/MI), `SMP` (SMP/MTs/SMA/SMK/MA), `TK` (TK/RA).
- **Strata** (4, **bertingkat/kumulatif**): `MINIMAL` → `STANDAR` → `OPTIMAL` → `PARIPURNA`. Untuk lulus strata X, semua indikator strata di bawahnya juga harus terpenuhi.
- **Komponen**: `PENKES`, `YANKES`, `LINGKUNGAN`, `MANAJEMEN`.
- Tiap **Indikator** = pernyataan + daftar **Sub-indikator**. Dijawab **Ada/Tidak Ada** (Tidak Ada → wajib keterangan).
- **Sumber**: `CEKLIS_STRATIFIKASI_UKS.xlsx` (sheet `SDMI`, `SMPMTsSMASMKMA`, `TK`; kolom `No | Indikator(Komponen) | Strata | Instrumen Penilaian | Ada | Tidak Ada(keterangan)`).

---

## 7. Model data (Eloquent)

### 7.1 Master
- `KabupatenKota(nama, kode)`
- `Kecamatan(nama, kode, kabupaten_kota_id)`
- `Sekolah(npsn[unik,8], nama, jenjang[SDMI|SMP|TK], status[Negeri|Swasta], kecamatan_id, alamat, nama_kepsek, no_telp, terverifikasi, strata_terkini)`
- `Profil` — §5.1

### 7.2 Katalog instrumen (versi-able)
- `Indikator(versi, jenjang, strata, komponen, nomor_urut, pernyataan, aktif)`
- `SubIndikator(indikator_id, kode, isi, nomor_urut)`

### 7.3 Transaksi
- `Pengajuan(sekolah_id, tahun, jenjang, strata_tujuan, status, skor_cache, dibuat_oleh_profil_id, timestamps)` — unik per `(sekolah_id, tahun, strata_tujuan)`
- `JawabanIndikator(pengajuan_id, indikator_id, pernyataan_snapshot, jawaban[ADA|TIDAK_ADA|null], keterangan)`
- `BuktiDukung(jawaban_indikator_id, path, nama_asli, tipe, ukuran, timestamps)`
- `Verifikasi(pengajuan_id, level[KEC|KAB|PROV], aktor_profil_id, aksi[SETUJUI|KEMBALIKAN|TOLAK], catatan, timestamps)` — **audit**
- `LogAktivitas(aktor, aksi, objek, timestamps)` — opsional

**Relasi inti**: `KabupatenKota 1—N Kecamatan 1—N Sekolah 1—N Pengajuan 1—N JawabanIndikator 1—N BuktiDukung`; `Indikator 1—N JawabanIndikator`; `Pengajuan 1—N Verifikasi`.

---

## 7A. Skema Database (MySQL) & phpMyAdmin

> **Catatan penting:** sumber kebenaran struktur tabel tetap **migration Laravel** (`php artisan migrate`). DDL di bawah adalah **acuan/referensi** skema yang sama — berguna untuk dibuka/divisualisasikan di **phpMyAdmin**, untuk dokumentasi, atau impor cepat saat ujicoba. Jangan menjalankan DDL ini sekaligus dengan migration di database yang sama (pilih salah satu).
> Konvensi: semua tabel `ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`. Nama tabel di-set eksplisit di Model (`protected $table`) agar rapi (hindari pluralisasi otomatis seperti `kabupaten_kotas`).

### 7A.1 Daftar tabel
`users` (auth bawaan Laravel) · `profil` · `kabupaten_kota` · `kecamatan` · `sekolah` · `indikator` · `sub_indikator` · `pengajuan` · `jawaban_indikator` · `bukti_dukung` · `verifikasi` · `log_aktivitas` (opsional).

### 7A.2 DDL (MySQL)
```sql
-- charset & engine berlaku untuk semua tabel
SET NAMES utf8mb4;

-- users: dari Laravel/Breeze (referensi, biasanya sudah dibuat migration bawaan)
-- CREATE TABLE users (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
--   name VARCHAR(255), email VARCHAR(255) UNIQUE, email_verified_at TIMESTAMP NULL,
--   password VARCHAR(255), remember_token VARCHAR(100) NULL,
--   created_at TIMESTAMP NULL, updated_at TIMESTAMP NULL) ENGINE=InnoDB;

CREATE TABLE kabupaten_kota (
  id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nama          VARCHAR(100) NOT NULL,
  kode          VARCHAR(10)  NULL,
  created_at    TIMESTAMP NULL, updated_at TIMESTAMP NULL,
  UNIQUE KEY uq_kabkota_nama (nama)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE kecamatan (
  id                 BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  kabupaten_kota_id  BIGINT UNSIGNED NOT NULL,
  nama               VARCHAR(100) NOT NULL,
  kode               VARCHAR(10)  NULL,
  created_at TIMESTAMP NULL, updated_at TIMESTAMP NULL,
  KEY idx_kec_kabkota (kabupaten_kota_id),
  CONSTRAINT fk_kec_kabkota FOREIGN KEY (kabupaten_kota_id)
    REFERENCES kabupaten_kota(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE sekolah (
  id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  npsn            VARCHAR(8)  NOT NULL,
  nama            VARCHAR(150) NOT NULL,
  jenjang         ENUM('SDMI','SMP','TK') NOT NULL,
  status          ENUM('Negeri','Swasta') NOT NULL DEFAULT 'Negeri',
  kecamatan_id    BIGINT UNSIGNED NOT NULL,
  alamat          TEXT NULL,
  nama_kepsek     VARCHAR(120) NULL,
  no_telp         VARCHAR(30) NULL,
  terverifikasi   TINYINT(1) NOT NULL DEFAULT 0,
  strata_terkini  ENUM('MINIMAL','STANDAR','OPTIMAL','PARIPURNA') NULL,
  created_at TIMESTAMP NULL, updated_at TIMESTAMP NULL,
  UNIQUE KEY uq_sekolah_npsn (npsn),
  KEY idx_sekolah_kec (kecamatan_id),
  CONSTRAINT fk_sekolah_kec FOREIGN KEY (kecamatan_id)
    REFERENCES kecamatan(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE profil (
  id                  BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id             BIGINT UNSIGNED NOT NULL,
  peran               ENUM('OPERATOR','VERIF_KEC','VERIF_KAB','VERIF_PROV','ADMIN') NOT NULL,
  sekolah_id          BIGINT UNSIGNED NULL,
  kecamatan_id        BIGINT UNSIGNED NULL,
  kabupaten_kota_id   BIGINT UNSIGNED NULL,
  no_hp               VARCHAR(30) NULL,
  nip                 VARCHAR(30) NULL,
  aktif               TINYINT(1) NOT NULL DEFAULT 1,
  harus_ganti_password TINYINT(1) NOT NULL DEFAULT 1,
  terakhir_login      TIMESTAMP NULL,
  created_at TIMESTAMP NULL, updated_at TIMESTAMP NULL,
  UNIQUE KEY uq_profil_user (user_id),
  KEY idx_profil_peran (peran),
  CONSTRAINT fk_profil_user   FOREIGN KEY (user_id)            REFERENCES users(id)           ON DELETE CASCADE,
  CONSTRAINT fk_profil_sek    FOREIGN KEY (sekolah_id)         REFERENCES sekolah(id)         ON DELETE SET NULL,
  CONSTRAINT fk_profil_kec    FOREIGN KEY (kecamatan_id)       REFERENCES kecamatan(id)       ON DELETE SET NULL,
  CONSTRAINT fk_profil_kabkot FOREIGN KEY (kabupaten_kota_id)  REFERENCES kabupaten_kota(id)  ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE indikator (
  id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  versi       VARCHAR(20) NOT NULL DEFAULT '2025',
  jenjang     ENUM('SDMI','SMP','TK') NOT NULL,
  strata      ENUM('MINIMAL','STANDAR','OPTIMAL','PARIPURNA') NOT NULL,
  komponen    ENUM('PENKES','YANKES','LINGKUNGAN','MANAJEMEN') NOT NULL,
  nomor_urut  INT NOT NULL DEFAULT 0,
  pernyataan  TEXT NOT NULL,
  aktif       TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP NULL, updated_at TIMESTAMP NULL,
  KEY idx_ind_jenjang_strata (jenjang, strata)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE sub_indikator (
  id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  indikator_id BIGINT UNSIGNED NOT NULL,
  kode         VARCHAR(10) NULL,
  isi          TEXT NOT NULL,
  nomor_urut   INT NOT NULL DEFAULT 0,
  created_at TIMESTAMP NULL, updated_at TIMESTAMP NULL,
  KEY idx_sub_ind (indikator_id),
  CONSTRAINT fk_sub_ind FOREIGN KEY (indikator_id)
    REFERENCES indikator(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE pengajuan (
  id                    BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  sekolah_id            BIGINT UNSIGNED NOT NULL,
  tahun                 SMALLINT UNSIGNED NOT NULL,
  jenjang               ENUM('SDMI','SMP','TK') NOT NULL,
  strata_tujuan         ENUM('MINIMAL','STANDAR','OPTIMAL','PARIPURNA') NOT NULL,
  status                ENUM('DRAFT','VERIF_KEC','VERIF_KAB','VERIF_PROV','REVISI','DISETUJUI','DITOLAK') NOT NULL DEFAULT 'DRAFT',
  skor_cache            TINYINT UNSIGNED NOT NULL DEFAULT 0,
  dibuat_oleh_profil_id BIGINT UNSIGNED NULL,
  created_at TIMESTAMP NULL, updated_at TIMESTAMP NULL,
  UNIQUE KEY uq_pengajuan (sekolah_id, tahun, strata_tujuan),
  KEY idx_pengajuan_status (status),
  CONSTRAINT fk_peng_sek    FOREIGN KEY (sekolah_id)            REFERENCES sekolah(id) ON DELETE CASCADE,
  CONSTRAINT fk_peng_profil FOREIGN KEY (dibuat_oleh_profil_id) REFERENCES profil(id)  ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE jawaban_indikator (
  id                  BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  pengajuan_id        BIGINT UNSIGNED NOT NULL,
  indikator_id        BIGINT UNSIGNED NOT NULL,
  pernyataan_snapshot TEXT NOT NULL,
  jawaban             ENUM('ADA','TIDAK_ADA') NULL,
  keterangan          TEXT NULL,
  created_at TIMESTAMP NULL, updated_at TIMESTAMP NULL,
  UNIQUE KEY uq_jawaban (pengajuan_id, indikator_id),
  KEY idx_jwb_peng (pengajuan_id),
  CONSTRAINT fk_jwb_peng FOREIGN KEY (pengajuan_id) REFERENCES pengajuan(id) ON DELETE CASCADE,
  CONSTRAINT fk_jwb_ind  FOREIGN KEY (indikator_id) REFERENCES indikator(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE bukti_dukung (
  id                   BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  jawaban_indikator_id BIGINT UNSIGNED NOT NULL,
  path                 VARCHAR(255) NOT NULL,
  nama_asli            VARCHAR(255) NOT NULL,
  tipe                 VARCHAR(20)  NOT NULL,
  ukuran               INT UNSIGNED NOT NULL DEFAULT 0,
  created_at TIMESTAMP NULL, updated_at TIMESTAMP NULL,
  KEY idx_bukti_jwb (jawaban_indikator_id),
  CONSTRAINT fk_bukti_jwb FOREIGN KEY (jawaban_indikator_id)
    REFERENCES jawaban_indikator(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE verifikasi (
  id               BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  pengajuan_id     BIGINT UNSIGNED NOT NULL,
  level            ENUM('KEC','KAB','PROV') NOT NULL,
  aktor_profil_id  BIGINT UNSIGNED NULL,
  aksi             ENUM('SETUJUI','KEMBALIKAN','TOLAK') NOT NULL,
  catatan          TEXT NULL,
  created_at TIMESTAMP NULL, updated_at TIMESTAMP NULL,
  KEY idx_verif_peng (pengajuan_id),
  CONSTRAINT fk_verif_peng   FOREIGN KEY (pengajuan_id)    REFERENCES pengajuan(id) ON DELETE CASCADE,
  CONSTRAINT fk_verif_profil FOREIGN KEY (aktor_profil_id) REFERENCES profil(id)    ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE log_aktivitas (
  id               BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  aktor_profil_id  BIGINT UNSIGNED NULL,
  aksi             VARCHAR(100) NOT NULL,
  objek            VARCHAR(150) NULL,
  created_at TIMESTAMP NULL, updated_at TIMESTAMP NULL,
  KEY idx_log_aktor (aktor_profil_id),
  CONSTRAINT fk_log_profil FOREIGN KEY (aktor_profil_id) REFERENCES profil(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

### 7A.3 Catatan desain skema
- **`utf8mb4`** dipilih agar mendukung teks Indonesia + emoji/simbol dengan aman.
- **ENUM** dipakai untuk nilai tetap (peran, status, strata, jenjang). Bila instrumen sering berubah, boleh diganti tabel referensi — tetapi untuk tahap ini ENUM cukup & jelas.
- **`UNIQUE (sekolah_id, tahun, strata_tujuan)`** mencegah pengajuan ganda untuk strata yang sama di tahun yang sama.
- **`UNIQUE (pengajuan_id, indikator_id)`** memastikan satu jawaban per indikator per pengajuan.
- **ON DELETE**: data turunan (jawaban, bukti, verifikasi) ikut terhapus bila pengajuan dihapus (`CASCADE`); referensi katalog (`indikator`) di-`RESTRICT` agar katalog tidak terhapus saat masih dipakai; relasi ke `profil`/`sekolah` di profil di-`SET NULL` agar jejak audit tidak hilang.
- **Indeks** dipasang pada semua FK + `(jenjang,strata)` + `pengajuan.status` untuk mempercepat antrian verifikasi (§5A.3).
- File bukti **tidak** disimpan di DB — hanya `path`-nya. Berkas fisik ada di disk private (§9.2).

### 7A.4 Langkah pakai phpMyAdmin (lokal)
1. Pasang **XAMPP** atau **Laragon** (sudah berisi MySQL/MariaDB + phpMyAdmin). Jalankan Apache + MySQL.
2. Buka `http://localhost/phpmyadmin`.
3. Menu **Databases** → buat database `sekolah_sehat`, pilih collation **`utf8mb4_unicode_ci`** → *Create*.
4. Cocokkan `.env` Laravel:
   ```
   DB_CONNECTION=mysql
   DB_HOST=127.0.0.1
   DB_PORT=3306
   DB_DATABASE=sekolah_sehat
   DB_USERNAME=root
   DB_PASSWORD=
   ```
5. **Cara yang disarankan**: biarkan Laravel membuat tabel → `php artisan migrate --seed`. Lalu *refresh* phpMyAdmin untuk melihat & menelusuri tabel.
6. *(Opsional)* Untuk visualisasi relasi antar tabel di phpMyAdmin: buka database → tab **Designer** (memperlihatkan ERD foreign key).
7. *(Opsional, hanya jika tidak pakai migration)* Tab **SQL** → tempel DDL §7A.2 → *Go*. **Jangan** dicampur dengan `migrate` di DB yang sama.

> Backup cepat saat ujicoba: tab **Export** → format **SQL** → simpan `.sql`. Impor balik via tab **Import**.

---

## 8. Alur status pengajuan (state machine)
Logika di `app/Services/`. `Pengajuan.status`:

| Status | Arti | Aksi berikutnya |
|---|---|---|
| `DRAFT` | Operator mengisi | `ajukan()` → `VERIF_KEC` |
| `VERIF_KEC` | Menunggu kecamatan | setujui → `VERIF_KAB` / kembalikan → `REVISI` / tolak → `DITOLAK` |
| `VERIF_KAB` | Menunggu kab/kota | setujui → `VERIF_PROV` / kembalikan / tolak |
| `VERIF_PROV` | Menunggu provinsi | setujui → `DISETUJUI` / kembalikan / tolak |
| `REVISI` | Dikembalikan ke operator | perbaiki → `ajukan()` ulang |
| `DISETUJUI` | Final, strata ditetapkan | — |
| `DITOLAK` | Berhenti | — |

**Fungsi kunci (Service)**: `siapkanJawaban`, `simpanJawaban`, `lampirkanBukti`, `hitungSkor`, `validasiSebelumSubmit`, `ajukan`, `verifikasi`, `pastikanBisaDiedit`, `pastikanWewenang`.

### 8.3 Gerbang validasi sebelum submit (semua wajib lolos)
1. Semua indikator strata-tujuan **+ semua strata di bawahnya** sudah dijawab.
2. Setiap `TIDAK_ADA` punya `keterangan` non-kosong.
3. Setiap `ADA` punya minimal satu `BuktiDukung`.
Gagal → `ValidasiGagal` + daftar penyebab ditampilkan ke operator.

### 8.4 Aturan bisnis
Penguncian di luar `DRAFT`/`REVISI` · Catatan wajib saat kembalikan/tolak · **Strata hanya naik** (saat final & lebih tinggi) · Revisi mengulang dari kecamatan · Audit tiap tindakan.

---

## 9. Self-assessment operator per strata
1. **Pilih konteks**: tahun + jenjang (dari sekolah) + **strata tujuan** → muat indikator strata tujuan **+ semua strata di bawahnya** (kumulatif).
2. **Profil sekolah** lengkap (prasyarat submit).
3. **Isi instrumen** per Komponen → Indikator: tampil pernyataan + sub-indikator (panduan), pilih Ada/Tidak Ada; Tidak Ada → keterangan wajib; Ada → upload bukti (≥1); **autosave**.
4. **Progres & skor** dihitung server (`hitungSkor`).
5. **Pratinjau & kirim**: ringkasan + `validasiSebelumSubmit` → `ajukan()`.
6. **Pantau status**: timeline + riwayat `Verifikasi`; saat `REVISI` tampilkan catatan & buka kunci edit.

### 9.2 Bukti dukung (upload)
- Tipe: `pdf,jpg,jpeg,png,doc,docx`; maks ~5 MB/berkas (konfigurabel).
- Simpan di **disk private**: `bukti/{npsn}/{pengajuan_id}/...`. Akses lewat route terkontrol Policy (bukan URL publik).
- Banyak bukti per jawaban; hapus hanya saat `DRAFT`/`REVISI`.
- Kompres gambar saat unggah; validasi ekstensi/ukuran server-side; sanitasi nama berkas.

### 9.3 Acceptance criteria §9
- [ ] Strata `OPTIMAL` memuat indikator MINIMAL+STANDAR+OPTIMAL.
- [ ] `TIDAK_ADA` tanpa keterangan / `ADA` tanpa bukti → submit gagal.
- [ ] Skor tampil == `hitungSkor` server.
- [ ] Setelah submit, terkunci & masuk antrian kecamatan yang benar.

---

## 10. Route (Laravel `routes/web.php`, prefix grup + middleware peran)
```
GET  /                      → redirect dashboard sesuai peran
        auth: /login /logout /password (Breeze)
GET  /dashboard

# Operator (middleware: peran:OPERATOR)
GET/PUT  /sekolah/saya
GET      /pengajuan
GET/POST /pengajuan/baru
GET      /pengajuan/{pengajuan}/isi
POST     /pengajuan/{pengajuan}/jawaban/{jawaban}        # autosave
POST/DELETE /pengajuan/{pengajuan}/jawaban/{jawaban}/bukti
GET      /pengajuan/{pengajuan}/pratinjau
POST     /pengajuan/{pengajuan}/ajukan
GET      /pengajuan/{pengajuan}/status

# Verifikator (middleware: peran:VERIF_KEC,VERIF_KAB,VERIF_PROV)
GET   /verifikasi                       # antrian terfilter wilayah (§5A.3)
GET   /verifikasi/{pengajuan}           # Policy: pastikan wilayah
POST  /verifikasi/{pengajuan}/aksi      # setujui|kembalikan|tolak

# Admin (middleware: peran:ADMIN)
resource /admin/wilayah, /admin/sekolah, /admin/user
GET /laporan
GET /instrumen
```
Otorisasi: `Gate`/`Policy` (`PengajuanPolicy`, `VerifikasiPolicy`) + middleware `peran` kustom.

---

## 11. Pemetaan ke Laravel 12 (arsitektur konkret)

| Konsep PRD | Implementasi Laravel 12 |
|---|---|
| Model data (§7) | Eloquent models + migrations (`database/migrations`) |
| Master & demo | Seeders (`database/seeders`) + Factories |
| Lapisan logika (§8) | Kelas Service `app/Services/*Service.php` |
| Validasi input | Form Request `app/Http/Requests/*` |
| Otorisasi/RBAC (§4,§5A) | Policies `app/Policies/*` + Gate + middleware `peran` |
| Tampilan (§9,§10) | Blade `resources/views/` + komponen + Alpine.js |
| Auth & ganti password | Laravel Breeze (Blade) |
| Upload bukti (§9.2) | `Storage` disk **private**; download via controller berproteksi |
| Impor Excel (§13) | `maatwebsite/excel` + Artisan command `php artisan uks:impor-instrumen` |
| Seed wilayah (§5A) | Artisan command/seeder `WilayahSumbarSeeder` |
| Ekspor berat (M7) | Queue + Job |
| Test | Pest/PHPUnit (`tests/`) |

**Struktur folder relevan**
```
app/
  Models/            Sekolah.php Kecamatan.php KabupatenKota.php Profil.php
                     Indikator.php SubIndikator.php Pengajuan.php
                     JawabanIndikator.php BuktiDukung.php Verifikasi.php
  Services/          PengajuanService.php VerifikasiService.php SkorService.php
  Policies/          PengajuanPolicy.php VerifikasiPolicy.php
  Http/Controllers/  ...
  Http/Requests/     ...
  Http/Middleware/   PeranMiddleware.php
  Console/Commands/  ImporInstrumen.php
database/migrations/ ...   database/seeders/ ...
resources/views/uks/ ...
routes/web.php
storage/app/private/bukti/   # bukti (jangan publik, jangan commit)
```

**Lingkungan (`.env`)**: `DB_*`, `FILESYSTEM_DISK=local`, `APP_KEY` (di-generate), jangan commit.

---

## 12. Milestone (berurutan; tiap DoD harus lolos)
- **M0 Bootstrap**: `laravel new` + Breeze + Tailwind/Vite + DB connect. *DoD*: register/login jalan.
- **M1 Wilayah & master**: migrasi §7.1 + `WilayahSumbarSeeder` (19 kab/kota). *DoD*: 19 kab/kota terisi; relasi Sekolah→Kecamatan→KabKota benar.
- **M2 Katalog + impor**: migrasi §7.2 + command impor Excel 3 sheet. *DoD*: jumlah indikator per (jenjang,strata) cocok Excel; tampil di `/instrumen`.
- **M3 User & peran (§5)**: `Profil`, middleware `peran`, CRUD user + validasi konsistensi, Policy dasar. *DoD*: acceptance §5.5 lolos.
- **M4 Self-assessment (§9)**: pengajuan, isi instrumen kumulatif, autosave, upload bukti (disk private), skor server, validasi submit, `ajukan`. *DoD*: acceptance §9.3 lolos.
- **M5 Verifikasi berbasis wilayah (§8 & §5A)**: antrian terfilter wilayah, panel verifikasi, `verifikasi()` + audit, penguncian/revisi. *DoD*: acceptance §5A.4 lolos; alur DRAFT→DISETUJUI lewat 3 verifikator.
- **M6 Dashboard & rekap**: statistik strata per wilayah/jenjang, filter. *DoD*: angka == agregasi DB.
- **M7 Polish**: ekspor PDF/Excel, sertifikat, peta, notifikasi, kesiapan produksi.

---

## 13. Roadmap (urut prioritas)
1. Importer Excel (M2). 2. View operator (M4) & verifikator (M5). 3. Dashboard/peta/filter (M6). 4. Ekspor PDF/Excel & sertifikat. 5. Notifikasi (email/WA). 6. Kesiapan produksi (DB terkelola, object storage, queue, deploy).

---

## 14. Non-fungsional
- **Keamanan**: RBAC + wilayah ditegakkan server-side (Service+Policy); skor di server; bukti di disk private; CSRF aktif (bawaan Laravel); validasi & sanitasi upload.
- **Privasi**: data kesehatan/peserta didik sensitif — batasi per peran/wilayah; jangan simpan data nyata di repo/ujicoba.
- **Performa**: indeks pada FK & `(jenjang,strata)`; pagination; **hindari N+1** (eager loading `with()`); ekspor berat via queue.
- **Kompatibilitas**: halaman ringan; kompres foto; hindari JS berat.
- **Bahasa**: seluruh UI Bahasa Indonesia.

---

## 15. Test scenarios (QA)
1. Admin buat user tiap peran; `VERIF_KEC` tanpa kecamatan ditolak.
2. Operator pengajuan `STANDAR` → muat MINIMAL+STANDAR.
3. `TIDAK_ADA` tanpa keterangan / `ADA` tanpa bukti → submit gagal.
4. Submit sukses → `VERIF_KEC`, terkunci edit, masuk antrian kecamatan benar.
5. `VERIF_KEC` luar kecamatan buka pengajuan → 403.
6. `VERIF_KAB` hanya lihat kab/kotanya; `VERIF_PROV` lihat se-Sumbar.
7. Setujui KEC→KAB→PROV → `DISETUJUI`, `strata_terkini` naik.
8. Kembalikan tanpa catatan ditolak; dengan catatan → `REVISI`, operator bisa edit lagi.
9. Strata final < `strata_terkini` tidak menurunkannya.
10. Rekap dashboard == agregasi DB.
